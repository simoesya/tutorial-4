package tasks

import contributors.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

suspend fun loadContributorsChannels(
    service: GitHubService,
    req: RequestData,
    updateResults: suspend (List<User>, Boolean) -> Unit
) = coroutineScope {

    val repos = service
        .getOrgRepos(req.org)
        .also { logRepos(req, it) }
        .bodyList()

    val channel = Channel<List<User>>()
    val allUsers = mutableListOf<User>()

    repos.forEach { repo ->
        launch {
            val users = service
                .getRepoContributors(req.org, repo.name)
                .also { logUsers(repo, it) }
                .bodyList()

            channel.send(users)
        }
    }

    repeat(repos.size) { index ->
        val users = channel.receive()
        allUsers += users

        val completed = index == repos.size - 1

        updateResults(
            allUsers.aggregate(),
            completed
        )
    }

    channel.close()
}
